package com.cg.mHealthSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MHealthSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MHealthSystemApplication.class, args);
	}

}
